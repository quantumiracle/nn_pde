# AOS551_PINN_tf2

Simple examples of PINN using TF2, including the Burgers eqn continous time inference model in Raissi et al (2019) converted to TF2

This code was written for educational purposes. If you need these codes for research, please contact Ching-Yao Lai (cylai@princeton.edu) and Yongji Wang (yw1705@princeton.edu)
