# AOS551_PINN
Demonstration of physics informed neural networks (Raissi et al., 2019) using Jupyter Notebooks. Adapted from repository: https://github.com/maziarraissi/PINNs
